﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//using Windows.UI.Xaml.Media; 


namespace DRPApp2.Model
{
    class Tweets
    {
       /* public String Name { get; set; }
        public String Message { get; set; }
        public ImageSource Image { get; set; } */

    }
}
