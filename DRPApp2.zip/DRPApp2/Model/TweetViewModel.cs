﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



//Tweets.cs represents a tweet entity
//Tweet Model is the collection for data binding

namespace DRPApp2.Model
{
    class TweetViewModel
    {
      /*  private ObservableCollection<Tweet> _tweets;
        public ObservableCollection<Tweet> Tweets
        {
            get
            {
                if (_tweets == null)
                {
                    _tweets = new ObservableCollection<Tweet>();
                }

                return _tweets;
            }
        } */

    }
}
