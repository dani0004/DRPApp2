﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRPApp2
{
    class TwitterMessageData
    {
        //GetMessages();
    }

   /* public class TwitterData
    { public string textMessage { get; set; } }

    private void GetMessages()
    {
         if (NetworkInterface.GetIsNetworkAvailable()) 
            { 
                WebClient twitter = new WebClient(); 
                twitter.DownloadStringCompleted += new DownloadStringCompletedEventHandler(twitter_DownloadStringCompleted);                twitter.DownloadStringAsync(new Uri("http://api.twitter.com/1/statuses/user_timeline.xml?screen_name=" +  UserSearchBox.Text));            }
    }*/
}
