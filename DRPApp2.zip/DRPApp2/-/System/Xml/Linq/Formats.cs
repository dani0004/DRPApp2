﻿namespace System.Xml.Linq
{
	internal static class Formats
	{
		public const string XmlDate = "yyyy-MM-ddZ";
		public const string XmlDateTime = "yyyy-MM-ddTHH:mm:ssZ";
	}
}